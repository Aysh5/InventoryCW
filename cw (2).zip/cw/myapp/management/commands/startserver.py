from django.core.management.base import BaseCommand
import webbrowser


class Command(BaseCommand):
    help = 'Starts the Django development server and opens a web browser to a specific page.'

    def handle(self, *args, **options):
        # Start the Django development server
        self.stdout.write("Starting Django development server...")
        from django.core.management import call_command
        call_command('runserver')

        # Open a web browser to the desired page
        url = 'http://127.0.0.1:8000/signup/'  # Replace with your desired URL
        webbrowser.open(url)
