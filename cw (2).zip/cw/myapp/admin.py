from django.contrib import admin
from .models import Equipment,Reservation,User
# Register your models here.

admin.site.register(Equipment)
admin.site.register(Reservation)
admin.site.register(User)