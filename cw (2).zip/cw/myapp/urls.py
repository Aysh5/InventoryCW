from django.shortcuts import render
from django.urls import path
from . import views
from django.contrib.auth import views as log_views
from .views import adduser, your_success_view




urlpatterns = [
    path('', views.homepage),
    path('accountspage/', views.accountspage),
    path('navbar/', views.navbar, name='navbar'),
    path('main/',views.main, name="main"),
    path('account/',views.account, name="account"),
    path('equipmentuser/',views.equipmentuser, name="equipmentuser"),
    path('addequipment/',views.addequipment, name="addequipment"),
    path('bookingspage/',views.bookingspage, name="bookingspage"),
    path('signup/',views.signup, name="signup"),
    path('aboutus/',views.aboutus, name="aboutus"),
    path('accountspage/', views.accountspage, name='accountspage'),
    path('activate/<int:user_id>/', views.activate_user, name='activate_user'),
    path('delete/<int:user_id>/', views.delete_user, name='delete_user'),
    path('update/<int:user_id>/', views.update_user, name='update_user'),
    path('user-added-successfully/', your_success_view, name='user_added_successfully'),

path('logout/', log_views.LogoutView.as_view(template_name='myapp/logout.html'), name='logout'),
    path('add-user/', adduser, name='add_user'),
    
]





