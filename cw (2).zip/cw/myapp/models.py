from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Equipment(models.Model):
    DEVICE_TYPES = [
        ('pc/laptop', 'PC/Laptop'),
        ('vr headset', 'VR Headset'),
        ('camera/sensors', 'Camera/Sensors'),
        ('pc peripherals', 'PC Peripherals'),
        ('furniture', 'Furniture'),
        ('tripod', 'Tripod'),
        ('other', 'Other'),
    ]

    LOCATIONS = [
        ('xr lab', 'XR Lab'),
        ('xr lab blue cabinet', 'XR Lab Blue Cabinet'),
        ('xr lab blue cabinet large', 'XR Lab Blue Cabinet Large'),
        ('xr lab medium wooden cabinet', 'XR Lab Medium Wooden Cabinet'),
        ('other', 'Other'),
    ]

    STATUS_CHOICES = [
        ('available', 'Available'),
        ('repairing', 'Repairing'),
        ('on_loan', 'On Loan'),
        ('decommissioned', 'Decommissioned'),
    ]

    equipment_id = models.AutoField(primary_key=True)
    deviceName = models.CharField(max_length=100, unique=True, verbose_name="Device Name")
    deviceType = models.CharField(max_length=50, choices=DEVICE_TYPES, default='pc/laptop', verbose_name="Device Type")
    quantity = models.PositiveSmallIntegerField(default=1)
    audit = models.DateField(auto_now_add=True, verbose_name="Audit Date")
    location = models.CharField(max_length=50, choices=LOCATIONS, default='xr lab', verbose_name="Location")
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='available')
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.deviceName

class Reservation(models.Model):
    APPROVAL_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    reservation_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE)
    reservation_date = models.DateTimeField(auto_now_add=True)
    approval_status = models.CharField(max_length=20, choices=APPROVAL_CHOICES, default='pending')

    class Meta:
        unique_together = ('user', 'equipment')

    def __str__(self):
        return f"Reservation ID: {self.reservation_id}, User: {self.user.first_name}, Equipment: {self.equipment.deviceName}, Status: {self.approval_status}"
    
