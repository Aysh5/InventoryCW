from django.shortcuts import render

from myapp.forms import UserForm
from .models import Reservation, User
from django.shortcuts import render, redirect, get_object_or_404


# Create your views here.

def accountspage(request):
    return render (request, 'myapp/accountspage.html')

def homepage(request):
    return render (request, 'myapp/homepage.html')

def navbar(request):
    return render(request, 'navbar.html')

def main(request):
    return render(request, 'main.html')

def aboutus(request):
    return render(request, 'myapp/aboutus.html')

def adduser(request):
    return render(request, 'myapp/AddUser.html')

def equipmentuser(request):
    return render(request, 'myapp/equipmentuser.html')

def bookingspage(request):
    return render(request, 'myapp/bookingspage.html')

def addequipment(request):
    return render(request, 'myapp/AddEquipment.html')

def signup(request):
    return render(request, 'myapp/signup.html')

def account(request):
    users = User.objects.all()
    context = {'users': users}
    return render(request, 'myapp/account.html', context)

def activate_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    user.is_active = True
    user.save()
    return redirect('account')

def delete_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    user.delete()
    return redirect('account')

def update_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)

def add_user(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save() 
            return redirect('user_added_successfully')  
    else:
        form = UserForm()  

def your_success_view(request):
    return render(request, 'success.html')  

    return render(request, 'AddUser.html', {'form': form})





